import { React, useState } from "react";
import Cell from "./Cell";
import "./Board.css";

const createEmptyArray = (height, width) => {
  let data = [];
  for (let i = 0; i < height; i++) {
    data[i] = new Array();
    for (let j = 0; j < width; j++) {
      data[i].push({
        x: i,
        y: j,
        isMine: false,
        neighbor: 0,
        isRevealed: false,
        isEmpty: false,
        isFlagged: false,
      });
    }
  }
  return data;
};

const plantMines = (data, height, width, mines) => {
  let randomx,
    randomy,
    minesPlanted = 0;
  while (minesPlanted < mines) {
    randomx = Math.floor(Math.random() * width);
    randomy = Math.floor(Math.random() * height);
    if (!data[randomx][randomy].isMine) {
      data[randomx][randomy].isMine = true;
      minesPlanted++;
    }
  }
  return data;
};

const calculateNeighborMineCounts = (board) => {
  const directions = [
    [-1, -1],
    [-1, 0],
    [-1, 1],
    [0, -1],
    [0, 1],
    [1, -1],
    [1, 0],
    [1, 1],
  ];

  for (let x = 0; x < board.length; x++) {
    for (let y = 0; y < board[x].length; y++) {
      let neighborMineCount = 0;
      directions.forEach(([dx, dy]) => {
        let newX = x + dx;
        let newY = y + dy;
        if (
          newX >= 0 &&
          newX < board.length &&
          newY >= 0 &&
          newY < board[x].length &&
          board[newX][newY].isMine
        ) {
          neighborMineCount++;
        }
      });
      board[x][y].neighbor = neighborMineCount;
    }
  }
};

const initBoard = (height, width, mines) => {
  let data = createEmptyArray(height, width, mines);
  data = plantMines(data, height, width, mines);
  calculateNeighborMineCounts(data);

  return data;
};

const Board = ({ height, width, mines, updateFlags, flags }) => {
  const [board, setBoard] = useState(initBoard(height, width, mines));

  const handleClick = (x, y) => {
    const newBoard = [...board];
    if (board[x][y].isMine) {
      alert("You clicked on a mine, GAME OVER =(");
    }
    const revealCell = (x, y) => {
      if (x < 0 || x >= newBoard.length || y < 0 || y >= newBoard[x].length) {
        return;
      }

      const cell = newBoard[x][y];

      if (cell.isRevealed || cell.isFlagged) {
        return;
      }
      cell.isRevealed = true;
      if (cell.neighbor === 0) {
        for (let dx = -1; dx <= 1; dx++) {
          for (let dy = -1; dy <= 1; dy++) {
            revealCell(x + dx, y + dy);
          }
        }
      }
    };
    revealCell(x, y);
    setBoard(newBoard);
  };

  const handleRightClick = (x, y) => {
    const newBoard = [...board];
    if (board[x][y].isRevealed) {
      return;
    }
    if (board[x][y].isFlagged) {
      newBoard[x][y].isFlagged = false;
      updateFlags(flags + 1);
      setBoard(newBoard);
      return;
    }
    if (flags <= 0) {
      alert("You have no flags left!");
      return;
    }
    newBoard[x][y].isFlagged = true;
    setBoard(newBoard);
    updateFlags(flags - 1);
  };

  return (
    <div className="minesweeper-board">
      {board.map((row, x) => (
        <div className="row" key={x}>
          {row.map((cell, y) => (
            <Cell
              key={y}
              cell={cell}
              onClick={() => handleClick(x, y)}
              handleRightClick={() => handleRightClick(x, y)}
            />
          ))}
        </div>
      ))}
    </div>
  );
};

export default Board;
