import { React, useState } from "react";
import "./Cell.css";

const Cell = ({ cell, onClick, handleRightClick }) => {
  const getValue = () => {
    if (!cell.isRevealed && !cell.isFlagged) {
      return "⬜";
    } else {
      if (cell.isMine && !cell.isFlagged) {
        return "💣";
      } else if (cell.isFlagged) {
        return "🚩";
      } else if (cell.neighbor > 0) {
        return cell.neighbor;
      }
    }
  };

  return (
    <div
      className="cell shadow-5 pointer"
      onClick={onClick}
      onContextMenu={(e) => {
        e.preventDefault();
        handleRightClick(cell.x, cell.y);
      }}
    >
      {getValue()}
    </div>
  );
};

export default Cell;
