import { React, useState } from "react";
import Board from "./components/Board";
import ResponsiveAppBar from "./components/ResponsiveAppBar";
import Register from "./components/Register";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

const App = () => {
  const [flags, setFlags] = useState(10);
  const [status, setStatus] = useState(false);
  const [mines, setMines] = useState();

  const handleStart = (minesAmount) => {
    if (isNaN(+minesAmount)) {
      alert(
        "Please enter the amount of mines you would like to have in your game!"
      );
      return;
    } else {
      if (minesAmount >= 64 || minesAmount <= 0) {
        alert("Mines amount must be 1 - 63");
        return;
      }
      setMines(minesAmount);
      setFlags(minesAmount);
      setStatus(true);
    }
  };

  const updateFlags = (newFlags) => {
    setFlags(newFlags);
  };
  return (
    <div className="App">
      <Router>
        <ResponsiveAppBar flags={flags} status={status} />
        <Routes>
          <Route
            path="/"
            element={
              status ? (
                <div
                  className="minesweeper-board"
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    height: "100vh",
                  }}
                >
                  <Board
                    height={8}
                    width={8}
                    flags={flags}
                    mines={mines}
                    updateFlags={updateFlags}
                  />
                </div>
              ) : (
                <Register handleStart={handleStart} />
              )
            }
          />
        </Routes>
      </Router>
    </div>
  );
};

export default App;
